All audio files came from [Xeno-canto](https://www.xeno-canto.org/)

 
Azara_s Spinetail.wav
Chestnut-crowned Antpitta.wav
House Sparrow.wav
LICENSE.md
Red Crossbill.wav
White-breasted Wood-Wren.wav
