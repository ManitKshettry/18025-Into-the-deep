# On-device Machine Learning Codelabs

This repository contains sample code for several on-device machine learning codelabs. Check out the on-device machine learning pathways to learn more.

https://developers.google.com/learn/topics/on-device-ml#build-your-first-on-device-ml-app
